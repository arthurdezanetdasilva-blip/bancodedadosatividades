package dal;

import java.sql.*;

public class Mod_conexao {
    public static Connection conector() {
        java.sql.Connection conexao = null;
        // ATEN��O: O nome do banco aqui deve ser o mesmo que voc� criou no passo 1
        String url = "jdbc:mysql://localhost:3306/banco_de_dados_java"; 
        String user = "root"; // Seu usu�rio do MySQL
        String password = ""; // Sua senha do MySQL (geralmente vazia ou 'root')

        try {
            // Carrega o driver do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            conexao = DriverManager.getConnection(url, user, password);
            return conexao;
        } catch (Exception e) {
            // Se der erro, mostra no console
            System.out.println("Erro na conex�o: " + e.getMessage());
            return null;
        }
    }
}